package com.example.audioapp;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.example.audioapp.R;  // Ensure this matches your package name



import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView webView = findViewById(R.id.webView);

        // Enable JavaScript (optional)
        webView.getSettings().setJavaScriptEnabled(true);

        // Ensure links and redirects are handled within the WebView
        webView.setWebViewClient(new WebViewClient());

        // Load the website
        webView.loadUrl(" https://listenbeyond.com/app/full-audiobook ");
        webView.getSettings().setUserAgentString(webView.getSettings().getUserAgentString().replace("; wv",""));

        webView.getSettings().setJavaScriptEnabled(true); // Enable JavaScript
        webView.getSettings().setBuiltInZoomControls(true); // Enable zoom controls
        webView.getSettings().setDomStorageEnabled(true); // Enable DOM storage

    }
}
